interface Charger {
    void charge();
}