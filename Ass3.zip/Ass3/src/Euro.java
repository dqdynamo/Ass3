class Euro implements Charger {
    @Override
    public void charge() {
        System.out.println("The charger charges in Europe.");
    }
}