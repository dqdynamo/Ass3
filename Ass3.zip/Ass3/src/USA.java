class USA implements Charger {
    @Override
    public void charge() {
        System.out.println("The charger charges in the USA.");
    }
}